﻿using Form_Đăng_Nhập_Đăng_Ký;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quản_lý_Bán_Hàng
{
    public partial class QLMon : Form
    {
        MyDataTable dataTable = new MyDataTable();
        string maMon = "";
        public QLMon()
        {
            InitializeComponent();
        }
        private void LayDuLieu()
        {
            // Hiển thị dữ liệu của bảng DanhMuc lên ComboBox cboLoai

            MyDataTable danhmuc = new MyDataTable();
            danhmuc.OpenConnection();
            string danhmucSql = "SELECT * FROM DanhMuc";
            SqlCommand danhmucCmd = new SqlCommand(danhmucSql);
            danhmuc.Fill(danhmucCmd);
            cbLoai.DataSource = danhmuc;
            cbLoai.DisplayMember = "TenDanhMuc";
            cbLoai.ValueMember = "MaDanhMuc";
            // Lấy dữ liệu vào DataGridView 
            string danhmucsql = @"SELECT P.*,C.TenDanhMuc 
                                          FROM SanPham P,DanhMuc C 
                                            WHERE P.MaDanhMuc = C.MaDanhMuc";
            SqlCommand cmd = new SqlCommand(danhmucsql);
            dataTable.Fill(cmd);
            BindingSource binding = new BindingSource();
            binding.DataSource = dataTable;
            dgvquanly.DataSource = binding;
            bindingNavigator1.BindingSource = binding;

            // Liên kết dữ liệu từ DataGridView lên các control
            txtMaso.DataBindings.Clear();
            txtTenSanPham.DataBindings.Clear();
            txtGia.DataBindings.Clear();
            txtSoLuong.DataBindings.Clear();
            cbLoai.DataBindings.Clear();

            txtMaso.DataBindings.Add("Text", binding, "MaSanPham");
            txtTenSanPham.DataBindings.Add("Text", binding, "TenSanPham");
            txtGia.DataBindings.Add("Text", binding, "Gia");
            txtSoLuong.DataBindings.Add("Text", binding, "SoLuong");
            cbLoai.DataBindings.Add("SelectedValue", binding, "MaDanhMuc");
            dgvquanly.AutoGenerateColumns = false;


            // Hiển thị dữ liệu của bảng SanPham lên DataGridView dgvquanly


        }
        private void QLMon_Load(object sender, EventArgs e)
        {
            LayDuLieu();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Đánh dấu là Thêm mới
            maMon = "";
            // Xóa trắng các trường
            cbLoai.Text = "";
            txtMaso.Text = "";
            txtTenSanPham.Text = "";
            txtSoLuong.Text = "";
            txtGia.Text = "";
            txtMaso.Focus();
            // Làm mờ nút Thêm mới, Sửa và Xóa (tự code)
            btnThem.Enabled = false;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            // Làm sáng nút Lưu và Bỏ qua (tự code)
            btnLuu.Enabled = true;
            btnBo.Enabled = true;
            // Làm sáng cboLoaiSach, txtMaso, txtTenSanPham, txtGia, txtSoLuong (tự code)
            txtGia.Enabled = true;
            txtMaso.Enabled = true;
            txtSoLuong.Enabled = true;
            txtTenSanPham.Enabled = true;
            cbLoai.Enabled = true;
            label2.Enabled = true;
            label3.Enabled = true;
            label4.Enabled = true;
            label5.Enabled = true;
            label6.Enabled = true;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult kq;
            kq = MessageBox.Show("Bạn có muốn sách " + txtTenSanPham.Text + " không?", "Xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (kq == DialogResult.Yes)
            {
                string sql = @"DELETE FROM SanPham WHERE MaSanPham = @MaSanPham";
                SqlCommand cmd = new SqlCommand(sql);
                cmd.Parameters.Add("@MaSanPham", SqlDbType.NVarChar, 5).Value = txtMaso.Text;
                MessageBox.Show("Xóa sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Tải lại dữ liệu sau khi xóa

                dataTable.Update(cmd);
                // Tải lại form
                QLMon_Load(sender, e);

            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu
            if (cbLoai.Text.Trim() == "")
                MessageBox.Show("Chưa chọn loại sách!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtMaso.Text.Trim() == "")
                MessageBox.Show("Mã sách không được bỏ trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtTenSanPham.Text.Trim() == "")
                MessageBox.Show("Tiêu đề không được bỏ trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtGia.Text.Trim() == "")
                MessageBox.Show("Đơn giá không được bỏ trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtSoLuong.Text.Trim() == "")
                MessageBox.Show("Số lượng không được bỏ trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                try
                {
                    // Thêm mới
                    if (maMon == "")
                    {
                        string sql = @"INSERT INTO SanPham(MaSanPham,TenSanPham,Gia,SoLuong,MaDanhMuc)
                        VALUES(@MaSanPham,@TenSanPham,@Gia,@SoLuong,@MaDanhMuc)";
                        SqlCommand cmd = new SqlCommand(sql);
                        cmd.Parameters.Add("@MaSanPham", SqlDbType.NVarChar, 10).Value = txtMaso.Text;
                        cmd.Parameters.Add("@TenSanPham", SqlDbType.NVarChar, 50).Value = txtTenSanPham.Text;
                        cmd.Parameters.Add("@Gia", SqlDbType.Money).Value = txtGia.Text;
                        cmd.Parameters.Add("@SoLuong", SqlDbType.Int).Value = txtSoLuong.Text;
                        cmd.Parameters.Add("@MaDanhMuc", SqlDbType.Int).Value = cbLoai.SelectedValue.ToString();
                        dataTable.Update(cmd);
                    }
                    else // Sửa
                    {
                        string sql = @"UPDATE SanPham
                     SET    MaSanPham = @MaSanPhamMoi,
                            TenSanPham = @TenSanPhamMoi,
                            Gia = @DonGiaMoi,
                            SoLuong = @SoLuongMoi,
                            MaDanhMuc = @MaDanhMucMoi
                    WHERE   MaSanPham = @MaSanPhamCu";
                        SqlCommand cmd = new SqlCommand(sql);
                        cmd.Parameters.Add("@MaSanPhamMoi", SqlDbType.NVarChar, 10).Value = txtMaso.Text;
                        cmd.Parameters.Add("@MaSanPhamCu", SqlDbType.NVarChar, 10).Value = maMon;
                        cmd.Parameters.Add("@TenSanPhamMoi", SqlDbType.NVarChar, 50).Value = txtTenSanPham.Text;
                        cmd.Parameters.Add("@DonGiaMoi", SqlDbType.Money).Value = txtGia.Text;
                        cmd.Parameters.Add("@SoLuongMoi", SqlDbType.Int).Value = txtSoLuong.Text;
                        cmd.Parameters.Add("@MaDanhMucMoi", SqlDbType.Int).Value = cbLoai.SelectedValue.ToString();
                        dataTable.Update(cmd);
                    }
                    // Tải lại form
                    MessageBox.Show("Lưu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information); // **Thêm thông báo**
                   QLMon_Load(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnBo_Click(object sender, EventArgs e)
        {
            QLMon_Load(sender, e);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            maMon = txtMaso.Text;
            // Làm mờ nút Thêm mới, Sửa và Xóa (tự code)
            btnThem.Enabled = false;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            // Làm sáng nút Lưu và Bỏ qua (tự code)
            btnLuu.Enabled = true;
            btnBo.Enabled = true;
            // Làm sáng cboLoaiSach, txtMaso, txtTenSanPham, txtGia, txtSoLuong (tự code)
            txtGia.Enabled = true;
            txtMaso.Enabled = true;
            txtSoLuong.Enabled = true;
            txtTenSanPham.Enabled = true;
            cbLoai.Enabled = true;
            label6.Enabled = true;
            label2.Enabled = true;
            label3.Enabled = true;
            label4.Enabled = true;
            label5.Enabled = true;
            label6.Enabled = true;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
