﻿using Form_Đăng_Nhập_Đăng_Ký;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quản_lý_Bán_Hàng
{
    public partial class QLDanhMuc : Form
    {
        MyDataTable dataTable = new MyDataTable();
        string maDanhMuc = "";
        public QLDanhMuc()
        {
            InitializeComponent();
            dataTable.OpenConnection();
        }
        private void LayDuLieu()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM DanhMuc");
            dataTable.Fill(cmd);
            BindingSource binding = new BindingSource();
            binding.DataSource = dataTable;
            // Hiển thị dữ liệu vào DataGridView
            dgvLoai.DataSource = binding;
            // Liên kết dữ liệu từ DataGridView lên các control
            txtMaloai.DataBindings.Clear();
            txtTenloai.DataBindings.Clear();
            txtMaloai.DataBindings.Add("Text", binding, "MaDanhMuc");
            txtTenloai.DataBindings.Add("Text", binding, "TenDanhMuc");
        }


        private void QLDanhMuc_Load(object sender, EventArgs e)
        {
            LayDuLieu();
            // Làm sáng nút Thêm mới, Sửa và Xóa 
            btnThem.Enabled = true;
            btnSua.Enabled = true;
            btnXoa.Enabled = true;
            // Làm mờ nút Lưu và Bỏ qua 
            btnLuu.Enabled = false;
            btnBo.Enabled = false;
            // Làm mờ cboLoai, txtMaLoai, txtTenLoai
            txtMaloai.Enabled = false;
            txtTenloai.Enabled = false;
            label2.Enabled = false;
            label1.Enabled = false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        { // Đánh dấu là Thêm mới
            maDanhMuc = "";
            // Xóa trắng các trường
            txtMaloai.Text = "";
            txtTenloai.Text = "";
            // Làm mờ nút Thêm mới, Sửa và Xóa (tự code)
            btnThem.Enabled = false;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            // Làm sáng nút Lưu và Bỏ qua (tự code)
            btnLuu.Enabled = true;
            btnBo.Enabled = true;
            // Làm sáng cboLoaiSach, txtMaloai, txtTenloai, txtGia, txtSoLuong (tự code)
            txtMaloai.Enabled = true;
            txtTenloai.Enabled = true;
            label2.Enabled = true;
            label1.Enabled = true;

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            // Đánh dấu là Cập nhật
            maDanhMuc = txtMaloai.Text;
            // Làm mờ nút Thêm mới, Sửa và Xóa (tự code)
            btnThem.Enabled = false;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            // Làm sáng nút Lưu và Bỏ qua (tự code)
            btnLuu.Enabled = true;
            btnBo.Enabled = true;
            // Làm sáng cboLoaiSach, txtMaloai,txtTenloai
            txtMaloai.Enabled = true;
            txtTenloai.Enabled = true;
            label2.Enabled = true;
            label1.Enabled = true;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult kq;
            kq = MessageBox.Show("Bạn có muốn xóa " + txtTenloai.Text + " không?", "Xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (kq == DialogResult.Yes)
            {
                string sql = @"DELETE FROM DanhMuc WHERE MaDanhMuc = @MaDanhMuc";
                SqlCommand cmd = new SqlCommand(sql);
                cmd.Parameters.Add("@MaDanhMuc", SqlDbType.NVarChar, 5).Value = txtMaloai.Text;
                dataTable.Update(cmd);
                // Tải lại form
                QLDanhMuc_Load(sender, e);

            }
        }

        private void btnBo_Click(object sender, EventArgs e)
        {
            QLDanhMuc_Load(sender, e);
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu
            if (txtMaloai.Text.Trim() == "")
                MessageBox.Show("Mã loại không được để trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtTenloai.Text.Trim() == "")
                MessageBox.Show("Tên loại không được bỏ trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else
            {
                try
                {
                    // Thêm mới
                    if (maDanhMuc == "")
                    {
                        string sql = @"INSERT INTO DanhMuc(MaDanhMuc,TenDanhMuc)
                        VALUES(@MaDanhMuc,@TenDanhMuc)";
                        SqlCommand cmd = new SqlCommand(sql);
                        cmd.Parameters.Add("@MaDanhMuc", SqlDbType.NVarChar, 10).Value = txtMaloai.Text;
                        cmd.Parameters.Add("@TenDanhMuc", SqlDbType.NVarChar, 50).Value = txtTenloai.Text;
                        dataTable.Update(cmd);
                    }
                    else // Sửa
                    {
                        string sql = @"UPDATE DanhMuc
                     SET    MaDanhMuc = @MaDanhMucMoi,
                            TenDanhMuc = @TenDanhMucMoi,
                            MaDanhMuc = @MaDanhMucMoi
                    WHERE   MaDanhMuc = @MaDanhMucCu";
                        SqlCommand cmd = new SqlCommand(sql);
                        cmd.Parameters.Add("@MaDanhMucMoi", SqlDbType.NVarChar, 10).Value = txtMaloai.Text;
                        cmd.Parameters.Add("@MaDanhMucCu", SqlDbType.NVarChar, 10).Value = maDanhMuc;
                        cmd.Parameters.Add("@TenDanhMucMoi", SqlDbType.NVarChar, 50).Value = txtTenloai.Text;
                        dataTable.Update(cmd);
                    }
                    // Tải lại form
                    LayDuLieu(); // Cập nhật lại dữ liệu
                   QLDanhMuc_Load(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvLoai_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
