﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Đăng_Nhập_Đăng_Ký
{
    internal class MyDataTable : DataTable
    {
        SqlConnection connection;
        SqlDataAdapter adapter;
        SqlCommand command;

        public SqlConnection Connection { get; internal set; }

        public string ConnectionString()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder["Server"] = "DESKTOP-M0D4HK8\\SQLEXPRESS";
            builder["Database"] = "QuanLyBanHang";
            builder["Integrated Security"] = "True";
            return builder.ConnectionString;
        }
        public bool OpenConnection()
        {
            try
            {
                if (connection == null)
                    connection = new SqlConnection(ConnectionString());
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                return true;
            }
            catch
            {
                connection.Close();
                return false;
            }
        }

        public void Fill(SqlCommand selectCommand)
        {
            try
            {
                // Kiểm tra kết nối và mở kết nối nếu chưa
                if (connection == null || connection.State != ConnectionState.Open)
                    OpenConnection();

                // Đảm bảo selectCommand được gán kết nối đúng
                selectCommand.Connection = connection;

                // Tạo SqlDataAdapter và sử dụng nó để điền dữ liệu vào DataTable
                adapter = new SqlDataAdapter(selectCommand);
                this.Clear();  // Xóa dữ liệu cũ trước khi điền dữ liệu mới
                adapter.Fill(this);  // Điền dữ liệu vào DataTable
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi truy vấn", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        public int Update(SqlCommand insertUpdateDeleteCommand)
        {
            int result = 0;
            SqlTransaction transaction = null;
            try
            {
                transaction = connection.BeginTransaction();

                insertUpdateDeleteCommand.Connection = connection;
                insertUpdateDeleteCommand.Transaction = transaction;
                result = insertUpdateDeleteCommand.ExecuteNonQuery();

                this.AcceptChanges();
                transaction.Commit();
            }
            catch (Exception e)
            {
                if (transaction != null)
                    transaction.Rollback();
                MessageBox.Show("Lỗi: " + e.Message, "Lỗi truy vấn", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return result;
        }
       

    }
}

