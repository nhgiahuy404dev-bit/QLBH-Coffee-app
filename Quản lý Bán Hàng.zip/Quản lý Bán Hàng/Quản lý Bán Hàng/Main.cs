﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Quản_lý_Bán_Hàng
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
            QLDanhMuc qlDanhMuc = null;
            QLMon qLMon = null;
        }
        private QLDanhMuc qlDanhMuc;
        private QLMon qlMon;
        private void CloseAllChildForms()
        {
            foreach (Form child in this.MdiChildren)
            {
                child.Close();
            }
        }
        private void quảnLýLoạiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllChildForms();
            if (qlDanhMuc == null || qlDanhMuc.IsDisposed)
            {
                qlDanhMuc = new QLDanhMuc();
                qlDanhMuc.MdiParent = this;// Thiết lập MainForm làm MDI Parent
                qlDanhMuc.Show();
            }
        }

        private void quảnLýDanhSáchNướcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllChildForms();
            if (qlMon == null || qlMon.IsDisposed)
            {
                qlMon = new QLMon();
                qlMon.MdiParent = this;// Thiết lập MainForm làm MDI Parent
                qlMon.Show();
            }
        }
    }
}
