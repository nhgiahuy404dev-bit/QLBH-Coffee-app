﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quản_lý_Bán_Hàng
{
    public partial class Menu : Form
    {
        private Image[] images = new Image[] {
            Properties.Resources.pic1,  // Truy cập tài nguyên hình ảnh từ Resources
            Properties.Resources.pic2,
            Properties.Resources.pic3,
            Properties.Resources.pic4,
            Properties.Resources.pic5
        };
        private int currentImageIndex = 0;  // Chỉ số của ảnh hiện tại

        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            // Hiển thị ảnh đầu tiên khi form được tải
            ShowImage(currentImageIndex);
        }

        // Hàm để hiển thị ảnh theo chỉ số
        private void ShowImage(int index)
        {
            // Kiểm tra xem chỉ số ảnh có hợp lệ không
            if (index >= 0 && index < images.Length)
            {
                // Cập nhật hình ảnh cho PictureBox
                pbMenu.Image = images[index];  // Hiển thị hình ảnh từ Resources
                pbMenu.SizeMode = PictureBoxSizeMode.StretchImage;  // Cân chỉnh ảnh theo kích thước PictureBox
            }
        }

        // Sự kiện khi nhấn nút Tiến
        private void btnTien_Click(object sender, EventArgs e)
        {
            // Tiến lên ảnh tiếp theo
            currentImageIndex++;

            // Nếu chỉ số vượt quá giới hạn thì quay lại đầu danh sách ảnh
            if (currentImageIndex >= images.Length)
            {
                currentImageIndex = 0;  // Quay lại ảnh đầu tiên
            }

            ShowImage(currentImageIndex);  // Hiển thị ảnh mới
        }

        // Sự kiện khi nhấn nút Lùi
        private void btnLui_Click(object sender, EventArgs e)
        {
            // Lùi về ảnh trước
            currentImageIndex--;

            // Nếu chỉ số âm thì quay lại ảnh cuối cùng
            if (currentImageIndex < 0)
            {
                currentImageIndex = images.Length - 1;  // Quay lại ảnh cuối cùng
            }

            ShowImage(currentImageIndex);  // Hiển thị ảnh mới
        }
    }
}
